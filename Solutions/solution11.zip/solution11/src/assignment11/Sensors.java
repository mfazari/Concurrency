package assignment11;

interface Sensors {

	   public void update(long timestamp, double[] data);

	   public long get(double[] data);
	   
}
