package ethz.ch.pp.mergeSort;

public class MergeSortMulti {

	//TODO: implement using ForkJoinPool and RecursiveAction 
	public static int[] sort(int[] input, int numThreads) {
		return input;
	}

}
