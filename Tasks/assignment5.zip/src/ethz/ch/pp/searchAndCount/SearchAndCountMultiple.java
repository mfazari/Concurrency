package ethz.ch.pp.searchAndCount;

import ethz.ch.pp.util.Workload;

public class SearchAndCountMultiple {	
	
	//TODO: implement using ForkJoinPool and RecursiveTask
	public static Integer countNoAppearances(int[] input, int cutOff,
			Workload.Type wt, int noThreads) {
		return 0;
	}

}