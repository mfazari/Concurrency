package assignment13.MPI;
import mpi.*;

public class HelloWorld {
	
	public static void main(String[] args) {
		// Add MPI ``Hello World'' implementation.
	}

}
