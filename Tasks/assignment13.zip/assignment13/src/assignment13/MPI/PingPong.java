package assignment13.MPI;
import mpi.*;

public class PingPong {
	
	static private int BufferSize = 1;
	static private int Buffer[] = new int[BufferSize];
	static private int Iterations = 512;
	
	public static void main(String[] args) {
		// Add Ping Pong implementation.
	}
}
