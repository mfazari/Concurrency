package assignment9.Database;

public class MySemaphore {

	private volatile int count;

	public MySemaphore(int maxCount) {
		//TODO initialize count suitably
	}

	public void acquire() throws InterruptedException {
		//TODO implment suitable monitor and implement semaphore acquisition
	}

	public void release() {
		//TODO implment suitable monitor and implement semaphore release
	}

}
