package assignment9.Database;

public class MyBarrier {

	MyBarrier(int n){
		//TODO find suitable variables for the barrier and initialize them
    }

	synchronized void await() {
		//TODO implement the barrier await using Monitors
	}
}