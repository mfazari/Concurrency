package assignment8.random;

public interface RandomInterface {
	public int nextInt();
}
