package ethz.ch.pp.fib;

import java.math.BigInteger;

public class FibonacciSeqCache implements IFibonacci {
	
	@Override
	public BigInteger fib(int n) {
		return BigInteger.ZERO;
	}		
	
}
