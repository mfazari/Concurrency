package ethz.ch.pp.fib;

import java.math.BigInteger;

public interface IFibonacci {
	BigInteger fib(int n);
}
