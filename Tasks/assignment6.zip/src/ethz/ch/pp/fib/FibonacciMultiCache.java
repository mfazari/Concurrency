package ethz.ch.pp.fib;

import java.math.BigInteger;
import java.util.concurrent.RecursiveTask;


public class FibonacciMultiCache extends RecursiveTask<BigInteger> implements IFibonacci {	
	
	private static final long serialVersionUID = -5889309543771277318L;

	@Override
	public BigInteger fib(int n) {
		// TODO Implement
		return BigInteger.ZERO;
	}

	@Override
	protected BigInteger compute() {
		// TODO Implement
		return BigInteger.ZERO;
	}
}
