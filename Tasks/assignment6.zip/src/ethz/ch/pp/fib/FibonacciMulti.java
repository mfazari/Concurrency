package ethz.ch.pp.fib;

import java.math.BigInteger;
import java.util.concurrent.RecursiveTask;

public class FibonacciMulti extends RecursiveTask<BigInteger> implements IFibonacci {

	private static final long serialVersionUID = -8352639308306099303L;

	@Override
	public BigInteger fib(int n) {
		// TODO Implement
		return BigInteger.ZERO;
	}

	@Override
	protected BigInteger compute() {
		// TODO Implement
		return BigInteger.ZERO;
	}

}
