package ethz.ch.pp.assignment3.counters;

//TODO: implement
public class SequentialCounter implements Counter {

}