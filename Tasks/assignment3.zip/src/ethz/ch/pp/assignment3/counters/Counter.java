package ethz.ch.pp.assignment3.counters;

public interface Counter {    
    public void increment();    
    public int value();
}
